import { default as addAnswersToRecords_1_0 } from './functions/addAnswersToRecords/1.0';
import { default as addOptionsToUser_1_0 } from './functions/AddOptionsToUser/1.0';

const fn = {
  "addAnswersToRecords 1.0": addAnswersToRecords_1_0,
  "addOptionsToUser 1.0": addOptionsToUser_1_0,
};

export default fn;
