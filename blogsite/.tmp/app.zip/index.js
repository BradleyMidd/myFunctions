import { default as sayHello_1_0 } from './functions/say-hello/1.0';

const fn = {
  "sayHello 1.0": sayHello_1_0,
};

export default fn;
